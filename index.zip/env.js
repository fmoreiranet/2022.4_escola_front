const process = {
    env: {
        URL_API: "http://localhost/projetos/escola_back/",
    }
}
//http://localhost/projetos/escola_back/
//https://escolaweb2.000webhostapp.com/api/
//https://api.fabianomoreira.x10.mx/