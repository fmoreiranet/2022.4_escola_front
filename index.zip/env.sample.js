const process = {
    env: {
        URL_API: "http://localhost/api/",
    }
}